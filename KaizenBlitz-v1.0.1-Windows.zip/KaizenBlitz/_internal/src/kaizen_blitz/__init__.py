"""Kaizen Blitz application package."""

__version__ = "1.0.0"
__author__ = "Your Company"
