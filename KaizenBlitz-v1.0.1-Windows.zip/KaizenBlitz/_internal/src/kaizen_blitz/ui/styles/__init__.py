"""Styles package."""

from .colors import Colors

__all__ = ["Colors"]
