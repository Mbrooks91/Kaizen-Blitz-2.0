"""Widgets package."""

from .project_card import ProjectCard

__all__ = ["ProjectCard"]
